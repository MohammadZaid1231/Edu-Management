<?php
?>
<head>
 <title>Login fail</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
 <link rel="stylesheet" href="external_css_signup.css">
</head>
 <body>
   <div class="centered">
   <div class="login_box">
    Login failed. <br> Invalid username or password or mismatched branch.
   </div>
   <a href="index.html">Try again</a>
   </div>
 </body>  
            
    
</html>